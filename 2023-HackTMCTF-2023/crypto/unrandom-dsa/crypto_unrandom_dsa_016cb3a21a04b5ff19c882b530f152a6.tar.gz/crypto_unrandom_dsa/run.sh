#!/bin/sh
timeout --kill-after=1s 10m ./server.py
