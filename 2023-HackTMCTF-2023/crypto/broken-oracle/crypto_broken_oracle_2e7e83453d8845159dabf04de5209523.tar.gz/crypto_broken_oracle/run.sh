#!/bin/sh
timeout --kill-after=1s 5m ./server.py
